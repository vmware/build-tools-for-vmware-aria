###
# #%L
# abx-project
# %%
# Copyright (C) 2024 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
function handler($context, $inputs) {
    $inputsString = $inputs | ConvertTo-Json -Compress

    Write-Host "Inputs were $inputsString"

    $output = @("result", "done")

    return $output
}

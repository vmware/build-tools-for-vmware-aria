###
# #%L
# abx-project
# %%
# Copyright (C) 2024 TODO: Enter Organization name
# %%
# TODO: Define header text
# #L%
###
import json

def handler(context, inputs):
    jsonOut=json.dumps(inputs, separators=(',', ':'))
    print("Inputs were {0}".format(jsonOut))

    outputs = ["done"]

    return outputs

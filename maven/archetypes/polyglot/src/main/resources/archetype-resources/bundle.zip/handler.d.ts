export declare function handler(context: any, inputs: any, callback: Function): Promise<void>;
//# sourceMappingURL=handler.d.ts.map